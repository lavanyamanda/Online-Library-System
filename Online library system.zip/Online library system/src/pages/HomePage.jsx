import React from 'react';
import { Link } from 'react-router-dom';
import BookCard from '../components/BookCard';

const categories = ['Fiction', 'Non-Fiction', 'Sci-Fi', 'Romance', 'Biography'];

const popularBooks = [
  {
    id: 1,
    title: '1984',
    author: 'George Orwell',
    rating: 4.7,
    description: 'A dystopian novel.',
    category: 'Fiction'
  },
  {
    id: 2,
    title: 'Sapiens',
    author: 'Yuval Noah Harari',
    rating: 4.8,
    description: 'A brief history of humankind.',
    category: 'Non-Fiction'
  }
];

const HomePage = () => {
  return (
    <div className="home-container">
      <h1 className="head">Welcome to the Online Library </h1>

      <section>
        <h2>Book Categories</h2>
        <ul className="category-list">
          {categories.map((cat) => (
            <li key={cat}>
              <Link to={`/books/${cat.toLowerCase()}`}>{cat}</Link>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2>Popular Books</h2>
        {popularBooks.map((book) => (
          <BookCard key={book.id} book={book} />
        ))}
      </section>
    </div>
  );
};

export default HomePage;
