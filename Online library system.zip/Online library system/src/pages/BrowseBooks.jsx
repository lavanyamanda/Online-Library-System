import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import BookCard from '../components/BookCard';


const BrowseBooks = () => {
  const { category } = useParams(); 
  const books = useSelector((state) => state.books.bookList);
  const [searchTerm, setSearchTerm] = useState('');
  const [filtered, setFiltered] = useState([]);

  useEffect(() => {
    let filteredBooks = books;

    if (category) {
      filteredBooks = filteredBooks.filter(
        (book) => book.category.toLowerCase() === category.toLowerCase()
      );
    }

    if (searchTerm) {
      filteredBooks = filteredBooks.filter(
        (book) =>
          book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          book.author.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFiltered(filteredBooks);
  }, [books, category, searchTerm]);

  return (
    <div className="page-container">
      <h2>Browse Books {category && `- ${category}`}</h2>

      <div className="search-bar">
        <input  type="text" placeholder="Search by title or author..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
      </div>

      {filtered.length === 0 ? (
        <p>No books found.</p>
      ) : (
        filtered.map((book) => <BookCard key={book.id} book={book} />)
      )}

      <Link to="/">← Back to Home</Link>
    </div>
  );
};

export default BrowseBooks;
