import { Link } from 'react-router-dom';


const Navbar = () => {
  return (
    <nav className="navbar">
      <h2 className="navbar-head"> Online Library</h2>
      <div className="navbar-links">
        <Link to="/">Home</Link>
        <Link to="/browsebooks">Browse Books</Link>
        <Link to="/addbook">Add Book</Link>
      </div>
    </nav>
  );
};

export default Navbar;
