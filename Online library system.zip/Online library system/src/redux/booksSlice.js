import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  bookList: [
    {
      id: 1,
      title: '1984',
      author: 'George Orwell',
      description: 'A dystopian novel about totalitarian regime.',
      rating: 4.7,
      category: 'Fiction',
    },
    {
      id: 2,
      title: 'Sapiens',
      author: 'Yuval Noah Harari',
      description: 'A brief history of humankind.',
      rating: 4.8,
      category: 'Non-Fiction',
    },
    {
      id: 3,
      title: 'Dune',
      author: 'Frank Herbert',
      description: 'Sci-Fi epic on desert planet Arrakis.',
      rating: 4.6,
      category: 'Sci-Fi',
    },
  ],
};

const booksSlice = createSlice({
  name: 'books',
  initialState,
  reducers: {
    addBook(state, action) {
      state.bookList.push(action.payload);
    },
  },
});

export const { addBook } = booksSlice.actions;
export default booksSlice.reducer;
