import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { addBook } from '../redux/booksSlice';

const categories = ['Fiction', 'Non-Fiction', 'Sci-Fi', 'Romance', 'Biography'];

const AddBook = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: '',
    author: '',
    description: '',
    rating: '',
    category: categories[0]
  });

  const [errors, setErrors] = useState({});

  const validate = () => {
    const errs = {};
    if (!form.title.trim()) errs.title = 'Title is required';
    if (!form.author.trim()) errs.author = 'Author is required';
    if (!form.description.trim()) errs.description = 'Description is required';
    if (!form.rating) errs.rating = 'Rating is required';
    else if (isNaN(form.rating) || form.rating < 0 || form.rating > 5)
      errs.rating = 'Rating must be a number between 0 and 5';
    if (!form.category) errs.category = 'Category is required';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const newBook = {
      ...form,
      id: Date.now(),
      rating: Number(form.rating),
    };

    dispatch(addBook(newBook));
    navigate('/browsebooks');
  };

  return (
    <div className="page-container">
      <h2>Add a New Book</h2>
      <form className="book-form" onSubmit={handleSubmit} noValidate>
        <div>
          <label>Title</label><br />
          <input type="text"  name="title" value={form.title}  onChange={handleChange} />
          {errors.title && <p className="error-message">{errors.title}</p>}
        </div>

        <div>
          <label>Author</label><br />
          <input  type="text" name="author" value={form.author} onChange={handleChange}
          />
          {errors.author && <p className="error-message">{errors.author}</p>}
        </div>

        <div>
          <label>Description</label><br />
          <textarea name="description"  rows="4" value={form.description}  onChange={handleChange}  />
          {errors.description && <p className="error-message">{errors.description}</p>}
        </div>

        <div>
          <label>Rating (0 - 5)</label><br />
          <input   type="number"  name="rating" value={form.rating} onChange={handleChange}  min="0" max="5"  step="0.1" />
          {errors.rating && <p className="error-message">{errors.rating}</p>}
        </div>

        <div>
          <label>Category</label><br />
          <select name="category" value={form.category} onChange={handleChange}>
            {categories.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          {errors.category && <p className="error-message">{errors.category}</p>}
        </div>

        <button type="submit">Add Book</button>
      </form>
    </div>
  );
};

export default AddBook;
